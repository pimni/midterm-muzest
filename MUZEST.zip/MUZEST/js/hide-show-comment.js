function btComment() {
  var x = document.getElementById("comment-area");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
function btSched() {
  var x = document.getElementById("sched-area");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

