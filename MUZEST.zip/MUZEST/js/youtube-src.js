  var player;

  function onYouTubeIframeAPIReady() {

    var ctrlq = document.getElementById("youtube-audio");
    ctrlq.innerHTML = '<img id="youtube-icon" src=""/><div id="youtube-player"></div>';
    ctrlq.style.cssText = 'width:128px;margin:2em auto;cursor:pointer;cursor:hand;display:none'; //buttons size
    ctrlq.onclick = toggleAudio;
    
    player = new YT.Player('youtube-player', {
      height: '0',
      width: '0',
      videoId: ctrlq.dataset.videoid,
      playerVars: {
        autoplay: ctrlq.dataset.autoplay,
        loop: ctrlq.dataset.loop,
      },
      events: {
        'onReady': onPlayerReady,
        'onStateChange': onPlayerStateChange
      }
    });
  }

  function togglePlayButton(play) {
    // https://ibb.co/BfFq8YT // https://ibb.co/tbRd7xF
    document.getElementById("youtube-icon").src = play ? "https://i.imgur.com/B1nVNpe.png" : "https://i.imgur.com/Ca6YIz9.png";
  }

  function toggleAudio() {
    if (player.getPlayerState() == 1 || player.getPlayerState() == 3) {
      player.pauseVideo();
      togglePlayButton(false);
    } else {
      player.playVideo();
      togglePlayButton(true);
    }
  }

  function onPlayerReady(event) {
    //event.target.setVolume(100);
    player.setPlaybackQuality("small"); //highres, hd1080, hd720, large, medium, small
    document.getElementById("youtube-audio").style.display = "block";
    togglePlayButton(player.getPlayerState() !== 5);
  }

  function onPlayerStateChange(event) {
    if (event.data === 0) {
      togglePlayButton(false);
    }
  }