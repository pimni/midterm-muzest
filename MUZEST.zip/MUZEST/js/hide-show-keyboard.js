function btKeyboard() {
  var x = document.getElementById("keyboard-info");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}