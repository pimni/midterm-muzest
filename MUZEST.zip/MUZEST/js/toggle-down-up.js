function downup(x) {
  x.classList.toggle("fa-chevron-down");
}