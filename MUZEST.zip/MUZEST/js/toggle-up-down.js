function updown(x) {
  x.classList.toggle("fa-chevron-up");
}


